# Task_EasyPay

*Nuk funksionon nese nuk ka internet (vetem nese ruan te dhena lokalisht ne nje file dhe i perdor por nuk i rifreskon dot)
*Nuk ka shume elemente nga GUI.
